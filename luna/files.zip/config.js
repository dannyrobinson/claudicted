// config.js — YOUR API KEY GOES HERE
// This file is gitignored. Safe to paste your real key.

export const ANTHROPIC_API_KEY = 'REPLACE_WITH_YOUR_ANTHROPIC_API_KEY';
